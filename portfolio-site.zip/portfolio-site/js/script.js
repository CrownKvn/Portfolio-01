/**
 * =====================================================================
 * KIRAWNSAN K — PORTFOLIO SCRIPT
 * =====================================================================
 * Table of contents:
 *   1.  Shared state & feature-detection flags
 *   2.  Terminal typing effect
 *   3.  Scroll-reveal (IntersectionObserver)
 *   4.  3D skill orbit
 *   5.  Neural-network background canvas
 *   6.  Custom cursor
 *   7.  Hero parallax + glitch title trigger
 *   8.  3D tilt on project cards
 *   9.  Rotating world map (dot-matrix globe)
 *   10. Color transfer keyboard
 *   11. Bootstrap — run everything once the DOM is ready
 * =====================================================================
 */
'use strict';

/* ---------------------------------------------------------------------
   1. SHARED STATE & FEATURE-DETECTION FLAGS
   --------------------------------------------------------------------- */
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const isTouch = window.matchMedia('(hover: none), (pointer: coarse)').matches;


/* ---------------------------------------------------------------------
   2. TERMINAL TYPING EFFECT
   --------------------------------------------------------------------- */
function initTypingEffect() {
  const phrases = [
    'whoami',
    '→ Kirawnsan K, Full-Stack Developer',
    'cat interests.txt',
    '→ full-stack engineering, cybersecurity research'
  ];
  const el = document.getElementById('typed');
  if (!el) return;

  let phraseIndex = 0;
  let charIndex = 0;
  let deleting = false;

  function tick() {
    const current = phrases[phraseIndex];

    if (!deleting) {
      el.textContent = current.slice(0, charIndex + 1);
      charIndex++;
      if (charIndex === current.length) {
        deleting = true;
        setTimeout(tick, 1400);
        return;
      }
    } else {
      el.textContent = current.slice(0, charIndex - 1);
      charIndex--;
      if (charIndex === 0) {
        deleting = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
      }
    }
    setTimeout(tick, deleting ? 28 : 42);
  }

  tick();
}


/* ---------------------------------------------------------------------
   3. SCROLL-REVEAL (IntersectionObserver)
   --------------------------------------------------------------------- */
function initScrollReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
}


/* ---------------------------------------------------------------------
   4. 3D SKILL ORBIT
   --------------------------------------------------------------------- */
function initSkillOrbit() {
  const orbit = document.getElementById('orbit');
  if (!orbit) return;

  const skills = ['JavaScript', 'React', 'Node.js', 'C#', '.NET', 'Python', 'Java', 'PHP'];
  const radius = 150;

  skills.forEach((skill, i) => {
    const angle = (360 / skills.length) * i;
    const node = document.createElement('div');
    node.className = 'orbit-node';
    node.textContent = skill;
    node.style.transform = `translate(-50%,-50%) rotateY(${angle}deg) translateZ(${radius}px)`;
    orbit.appendChild(node);
  });
}


/* ---------------------------------------------------------------------
   5. NEURAL-NETWORK BACKGROUND CANVAS
   --------------------------------------------------------------------- */
function initNeuralNetBackground() {
  const canvas = document.getElementById('net-bg');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const mouse = { x: null, y: null };
  let width, height, particles = [];

  function resizeCanvas() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }

  function initParticles() {
    const count = Math.min(70, Math.floor((width * height) / 22000));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35
    }));
  }

  function drawFrame() {
    ctx.clearRect(0, 0, width, height);

    // update positions, with a gentle mouse-repulsion field
    for (const particle of particles) {
      particle.x += particle.vx;
      particle.y += particle.vy;
      if (particle.x < 0 || particle.x > width) particle.vx *= -1;
      if (particle.y < 0 || particle.y > height) particle.vy *= -1;

      if (mouse.x !== null) {
        const dx = particle.x - mouse.x;
        const dy = particle.y - mouse.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 120) {
          particle.x += (dx / dist) * 0.6;
          particle.y += (dy / dist) * 0.6;
        }
      }
    }

    // connect nearby particles, then draw the particle itself
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i];
        const b = particles[j];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < 140) {
          ctx.strokeStyle = `rgba(73,217,199,${0.16 * (1 - dist / 140)})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
      ctx.fillStyle = 'rgba(73,217,199,0.55)';
      ctx.beginPath();
      ctx.arc(particles[i].x, particles[i].y, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }

    requestAnimationFrame(drawFrame);
  }

  resizeCanvas();
  initParticles();
  window.addEventListener('resize', resizeCanvas);
  window.addEventListener('resize', initParticles);
  window.addEventListener('mousemove', (e) => { mouse.x = e.clientX; mouse.y = e.clientY; });
  window.addEventListener('mouseleave', () => { mouse.x = null; mouse.y = null; });

  // still draw a single static frame under reduced motion, just don't animate it
  if (!reduceMotion) requestAnimationFrame(drawFrame); else drawFrame();
}


/* ---------------------------------------------------------------------
   6. CUSTOM CURSOR
   --------------------------------------------------------------------- */
function initCustomCursor() {
  if (isTouch) return;

  const dot = document.getElementById('cursorDot');
  const ring = document.getElementById('cursorRing');
  if (!dot || !ring) return;

  let ringX = 0, ringY = 0, targetX = 0, targetY = 0;

  window.addEventListener('mousemove', (e) => {
    dot.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%,-50%)`;
    targetX = e.clientX;
    targetY = e.clientY;
  });

  (function easeRing() {
    ringX += (targetX - ringX) * 0.18;
    ringY += (targetY - ringY) * 0.18;
    ring.style.transform = `translate(${ringX}px, ${ringY}px) translate(-50%,-50%)`;
    requestAnimationFrame(easeRing);
  })();

  const hoverTargets = 'a, .project, .skill-card, .orbit-node, .avatar-ring, .key, .globe-wrap';
  document.querySelectorAll(hoverTargets).forEach((el) => {
    el.addEventListener('mouseenter', () => ring.classList.add('hover'));
    el.addEventListener('mouseleave', () => ring.classList.remove('hover'));
  });
}


/* ---------------------------------------------------------------------
   7. HERO PARALLAX + GLITCH TITLE TRIGGER
   --------------------------------------------------------------------- */
function initHeroInteractions() {
  const hero = document.querySelector('.hero');
  const heroTerminal = document.getElementById('heroTerminal');
  const heroTitle = document.getElementById('heroTitle');
  if (!hero || !heroTerminal || !heroTitle) return;

  if (!isTouch && !reduceMotion) {
    hero.addEventListener('mousemove', (e) => {
      const rect = hero.getBoundingClientRect();
      const mx = (e.clientX - rect.left) / rect.width - 0.5;
      const my = (e.clientY - rect.top) / rect.height - 0.5;
      heroTerminal.style.transform = `translate(${mx * 10}px, ${my * 10}px)`;
    });
  }

  heroTitle.addEventListener('mouseenter', () => {
    heroTitle.classList.remove('glitch-active');
    void heroTitle.offsetWidth; // restart the CSS animation
    heroTitle.classList.add('glitch-active');
  });
}


/* ---------------------------------------------------------------------
   8. 3D TILT ON PROJECT CARDS
   --------------------------------------------------------------------- */
function initProjectTilt() {
  if (isTouch || reduceMotion) return;

  document.querySelectorAll('.project').forEach((card) => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const px = ((e.clientX - rect.left) / rect.width) * 100;
      const py = ((e.clientY - rect.top) / rect.height) * 100;
      const rx = ((py - 50) / 50) * -4;
      const ry = ((px - 50) / 50) * 4;

      card.style.setProperty('--mx', `${px}%`);
      card.style.setProperty('--my', `${py}%`);
      card.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'rotateX(0deg) rotateY(0deg)';
    });
  });
}


/* ---------------------------------------------------------------------
   9. ROTATING WORLD MAP (dot-matrix globe)
   --------------------------------------------------------------------- */
function initWorldMapGlobe() {
  const wrap = document.getElementById('globeWrap');
  const canvas = document.getElementById('globeCanvas');
  const pinLabel = document.getElementById('globePinLabel');
  if (!wrap || !canvas || !pinLabel) return;

  const gctx = canvas.getContext('2d');

  // Rough continent outlines as [lon, lat] polygons — stylised, not survey-accurate,
  // but enough to render a recognisable dot-matrix globe.
  const CONTINENTS = [
    // Africa
    [[-17, 35], [10, 37], [20, 32], [32, 31], [44, 12], [51, 12], [48, 2], [42, -1],
     [40, -15], [35, -25], [27, -33], [18, -35], [12, -18], [8, 4], [-6, 5], [-10, 15], [-17, 20]],
    // Europe
    [[-10, 44], [-9, 53], [-5, 58], [5, 61], [15, 66], [28, 70], [35, 66], [45, 60],
     [45, 48], [38, 42], [27, 40], [15, 42], [5, 44], [-2, 44]],
    // Asia
    [[27, 40], [35, 45], [45, 48], [45, 60], [55, 68], [70, 72], [95, 74], [120, 72],
     [140, 60], [143, 50], [135, 42], [122, 32], [112, 22], [98, 10], [92, 5], [78, 8],
     [68, 18], [58, 25], [48, 30], [38, 35]],
    // North America
    [[-165, 68], [-155, 71], [-130, 71], [-95, 68], [-83, 58], [-80, 48], [-70, 45],
     [-65, 44], [-75, 32], [-80, 25], [-97, 18], [-105, 20], [-115, 30], [-124, 40],
     [-124, 49], [-135, 58], [-155, 60]],
    // South America
    [[-80, 10], [-70, 12], [-60, 10], [-50, 0], [-35, -6], [-38, -15], [-40, -23],
     [-48, -28], [-58, -35], [-68, -45], [-73, -42], [-75, -20], [-81, -5]],
    // Australia
    [[113, -22], [122, -18], [130, -12], [142, -11], [147, -19], [153, -28],
     [150, -34], [140, -38], [130, -32], [118, -33], [113, -26]]
  ];

  // Batticaloa, Sri Lanka
  const PIN = { lon: 81.7, lat: 7.7 };

  /** Ray-casting point-in-polygon test. */
  function pointInPolygon(lon, lat, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const [xi, yi] = poly[i];
      const [xj, yj] = poly[j];
      const intersects = ((yi > lat) !== (yj > lat)) &&
        (lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi);
      if (intersects) inside = !inside;
    }
    return inside;
  }

  /** Build the dot field once — a lat/lon grid filtered down to continent shapes. */
  function buildDotField() {
    const dots = [];
    for (let lat = -80; lat <= 80; lat += 3.2) {
      const lonStep = Math.max(3.2, 3.2 / Math.max(0.18, Math.cos((lat * Math.PI) / 180)));
      for (let lon = -180; lon < 180; lon += lonStep) {
        for (const poly of CONTINENTS) {
          if (pointInPolygon(lon, lat, poly)) {
            dots.push([lon, lat]);
            break;
          }
        }
      }
    }
    return dots;
  }

  const dots = buildDotField();

  // --- render state ---
  let rotationDeg = -80;    // current globe rotation
  let autoTarget = null;    // when set, eases rotation toward Sri Lanka
  let dragging = false;
  let lastPointerX = 0;
  let canvasWidth = 0, canvasHeight = 0, sphereRadius = 0;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  function resizeGlobe() {
    const rect = wrap.getBoundingClientRect();
    canvasWidth = rect.width;
    canvasHeight = rect.height;
    canvas.width = canvasWidth * dpr;
    canvas.height = canvasHeight * dpr;
    canvas.style.width = `${canvasWidth}px`;
    canvas.style.height = `${canvasHeight}px`;
    gctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    sphereRadius = Math.min(canvasWidth, canvasHeight) * 0.42;
  }

  /** Project a lat/lon point onto the unit sphere, given the current rotation. */
  function projectToSphere(lon, lat) {
    const theta = ((lon + rotationDeg) * Math.PI) / 180;
    const phi = (lat * Math.PI) / 180;
    return {
      x: Math.cos(phi) * Math.sin(theta),
      y: Math.sin(phi),
      z: Math.cos(phi) * Math.cos(theta)
    };
  }

  function drawGlobe() {
    gctx.clearRect(0, 0, canvasWidth, canvasHeight);
    const cx = canvasWidth / 2;
    const cy = canvasHeight / 2;

    // sphere rim
    gctx.beginPath();
    gctx.arc(cx, cy, sphereRadius, 0, Math.PI * 2);
    gctx.strokeStyle = 'rgba(73,217,199,0.18)';
    gctx.lineWidth = 1;
    gctx.stroke();

    // continent dots, front hemisphere only, shaded by depth
    for (const [lon, lat] of dots) {
      const p = projectToSphere(lon, lat);
      if (p.z < -0.05) continue;

      const px = cx + p.x * sphereRadius;
      const py = cy - p.y * sphereRadius;
      const depth = (p.z + 0.05) / 1.05;

      gctx.beginPath();
      gctx.arc(px, py, 0.9 + depth * 1.1, 0, Math.PI * 2);
      gctx.fillStyle = `rgba(73,217,199,${0.12 + depth * 0.65})`;
      gctx.fill();
    }

    // Sri Lanka pin — pulsing ring + glowing dot, with a floating label
    const pin = projectToSphere(PIN.lon, PIN.lat);
    const pinVisible = pin.z > 0.15;

    if (pinVisible) {
      const px = cx + pin.x * sphereRadius;
      const py = cy - pin.y * sphereRadius;
      const pulse = 3 + Math.sin(Date.now() / 260) * 1.4;

      gctx.beginPath();
      gctx.arc(px, py, pulse + 3, 0, Math.PI * 2);
      gctx.strokeStyle = 'rgba(255,180,84,0.5)';
      gctx.lineWidth = 1;
      gctx.stroke();

      gctx.beginPath();
      gctx.arc(px, py, 2.6, 0, Math.PI * 2);
      gctx.fillStyle = '#ffb454';
      gctx.shadowColor = '#ffb454';
      gctx.shadowBlur = 8;
      gctx.fill();
      gctx.shadowBlur = 0;

      pinLabel.style.left = `${px}px`;
      pinLabel.style.top = `${py}px`;
    }
    pinLabel.classList.toggle('on', pinVisible);
  }

  function tick() {
    if (!dragging) {
      if (autoTarget !== null) {
        const diff = ((autoTarget - rotationDeg + 540) % 360) - 180;
        rotationDeg += diff * 0.03;
        if (Math.abs(diff) < 0.3) autoTarget = null;
      } else {
        rotationDeg += reduceMotion ? 0 : 0.12;
      }
    }
    drawGlobe();
    requestAnimationFrame(tick);
  }

  // --- drag-to-spin, then auto-resume toward Sri Lanka ---
  let resumeTimer = null;

  function pointerDown(x) {
    dragging = true;
    lastPointerX = x;
    autoTarget = null;
    clearTimeout(resumeTimer);
  }

  function pointerMove(x) {
    if (!dragging) return;
    rotationDeg += (x - lastPointerX) * 0.4;
    lastPointerX = x;
  }

  function pointerUp() {
    if (!dragging) return;
    dragging = false;
    clearTimeout(resumeTimer);
    resumeTimer = setTimeout(() => {
      const target = -PIN.lon; // rotation that brings the pin to front-center
      autoTarget = ((target % 360) + 360) % 360;
    }, 1200);
  }

  resizeGlobe();
  window.addEventListener('resize', resizeGlobe);

  wrap.addEventListener('mousedown', (e) => pointerDown(e.clientX));
  window.addEventListener('mousemove', (e) => pointerMove(e.clientX));
  window.addEventListener('mouseup', pointerUp);
  wrap.addEventListener('touchstart', (e) => pointerDown(e.touches[0].clientX), { passive: true });
  wrap.addEventListener('touchmove', (e) => pointerMove(e.touches[0].clientX), { passive: true });
  wrap.addEventListener('touchend', pointerUp);

  tick();
}


/* ---------------------------------------------------------------------
   10. COLOR TRANSFER KEYBOARD
   --------------------------------------------------------------------- */
function initColorTransferKeyboard() {
  const kbViz = document.getElementById('keyboardViz');
  const swatch = document.getElementById('keySwatch');
  const hexOut = document.getElementById('keyHex');
  const charOut = document.getElementById('keyChar');
  const trail = document.getElementById('colorTrail');
  const kbGlow = document.getElementById('kbGlow');
  if (!kbViz || !swatch || !hexOut || !charOut || !trail) return;

  const KEY_ROWS = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
  ];

  const keyEls = {};

  /** Build the on-screen keyboard once. */
  function buildKeyboard() {
    KEY_ROWS.forEach((row) => {
      const rowEl = document.createElement('div');
      rowEl.className = 'kb-row';
      row.forEach((label) => {
        const keyEl = document.createElement('div');
        keyEl.className = 'key';
        keyEl.textContent = label;
        keyEl.dataset.key = label;
        rowEl.appendChild(keyEl);
        keyEls[label] = keyEl;
      });
      kbViz.appendChild(rowEl);
    });
  }

  /** Deterministic char → hue mapping, so a given key always produces the same color. */
  function hueForChar(ch) {
    const code = ch.toUpperCase().charCodeAt(0);
    return (code * 47) % 360;
  }

  function hslToHex(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    const toHex = (x) => Math.round(255 * x).toString(16).padStart(2, '0');
    return `#${toHex(f(0))}${toHex(f(8))}${toHex(f(4))}`;
  }

  /** A short-lived ripple ring inside the pressed key. */
  function spawnRipple(keyEl) {
    const ripple = document.createElement('span');
    ripple.className = 'key-ripple';
    keyEl.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  }

  /** Animate the picked color flying from the key to the trail strip. */
  function spawnFlyingOrb(fromEl, color, cardEl) {
    if (reduceMotion || !fromEl || !cardEl) return;

    const cardRect = cardEl.getBoundingClientRect();
    const startRect = fromEl.getBoundingClientRect();
    const endRect = trail.getBoundingClientRect();

    const startX = startRect.left + startRect.width / 2 - cardRect.left;
    const startY = startRect.top + startRect.height / 2 - cardRect.top;
    const endX = Math.min(endRect.left + endRect.width + 6, cardRect.right - 12) - cardRect.left;
    const endY = (endRect.top + Math.min(endRect.height, 10) / 2 - cardRect.top) ||
      (endRect.top - cardRect.top + 8);
    const midX = (startX + endX) / 2 + (Math.random() * 30 - 15);
    const midY = Math.min(startY, endY) - 46;

    const orb = document.createElement('div');
    orb.className = 'flying-orb';
    orb.style.background = color;
    orb.style.color = color;
    orb.style.left = `${startX}px`;
    orb.style.top = `${startY}px`;
    cardEl.appendChild(orb);

    const animation = orb.animate([
      { transform: 'translate(-50%,-50%) scale(1)', opacity: 1, offset: 0 },
      { transform: `translate(${midX - startX}px, ${midY - startY}px) translate(-50%,-50%) scale(0.75)`, opacity: 1, offset: 0.55 },
      { transform: `translate(${endX - startX}px, ${endY - startY}px) translate(-50%,-50%) scale(0.25)`, opacity: 0.15, offset: 1 }
    ], { duration: 560, easing: 'cubic-bezier(.3,.7,.4,1)' });

    animation.onfinish = () => orb.remove();
  }

  /** Briefly wash the whole card with the pressed key's color. */
  function pulseGlow(color) {
    if (!kbGlow) return;
    kbGlow.style.background = `radial-gradient(circle at 50% 20%, ${color}55, transparent 65%)`;
    kbGlow.animate(
      [{ opacity: 0 }, { opacity: 1, offset: 0.25 }, { opacity: 0 }],
      { duration: 450, easing: 'ease-out' }
    );
  }

  /** Restart a CSS animation on an element by toggling its class. */
  function flashText(el) {
    el.classList.remove('flash');
    void el.offsetWidth;
    el.classList.add('flash');
  }

  /** Core effect: map a character to a color and animate it through the widget. */
  function transferKeyToColor(ch, sourceEl) {
    const key = ch.toUpperCase();
    const color = hslToHex(hueForChar(key), 70, 58);
    const keyEl = sourceEl || keyEls[key];
    const cardEl = kbViz.closest('.lab-card');

    // readout swatch + text
    swatch.style.background = color;
    swatch.style.color = color;
    swatch.style.animation = 'none';
    void swatch.offsetWidth;
    swatch.style.animation = '';

    hexOut.textContent = color;
    charOut.textContent = `"${ch}"`;
    flashText(hexOut);
    flashText(charOut);

    pulseGlow(color);
    spawnFlyingOrb(keyEl, color, cardEl);

    // pressed-key feedback
    if (keyEl) {
      keyEl.style.background = color;
      keyEl.classList.remove('active');
      void keyEl.offsetWidth;
      keyEl.classList.add('active');
      keyEl.style.boxShadow = `0 0 14px ${color}aa`;
      spawnRipple(keyEl);
      setTimeout(() => {
        keyEl.classList.remove('active');
        keyEl.style.background = '';
        keyEl.style.boxShadow = '';
      }, 320);
    }

    // append to the trail once the flying orb has (roughly) arrived
    setTimeout(() => {
      const swatchEl = document.createElement('div');
      swatchEl.className = 'trail-swatch';
      swatchEl.style.background = color;
      swatchEl.style.color = color;
      trail.appendChild(swatchEl);
      while (trail.children.length > 60) trail.removeChild(trail.firstChild);
    }, reduceMotion ? 0 : 480);
  }

  buildKeyboard();

  window.addEventListener('keydown', (e) => {
    if (e.key.length === 1 && /[a-z0-9]/i.test(e.key)) transferKeyToColor(e.key);
  });

  Object.entries(keyEls).forEach(([label, keyEl]) => {
    keyEl.addEventListener('click', () => transferKeyToColor(label, keyEl));
  });
}


/* ---------------------------------------------------------------------
   11. BOOTSTRAP
   --------------------------------------------------------------------- */
function initPortfolio() {
  initTypingEffect();
  initScrollReveal();
  initSkillOrbit();
  initNeuralNetBackground();
  initCustomCursor();
  initHeroInteractions();
  initProjectTilt();
  initWorldMapGlobe();
  initColorTransferKeyboard();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPortfolio);
} else {
  initPortfolio();
}
